// Copyright (c) 2018 Illumina, Inc.
// All rights reserved.

// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:

// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer.

// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
// SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "graphIO/GraphJson.hh"

#include <fstream>

using std::string;

namespace graphtools
{

Graph loadGraph(string const& jsonPath)
{
    std::ifstream jsonFile(jsonPath);
    assert(jsonFile.good());
    Json json;
    jsonFile >> json;
    return parseGraph((json.count("graph") == 1) ? json["graph"] : json);
}

Graph parseGraph(Json const& jGraph)
{
    Json::array_t nodes = jGraph["nodes"];
    auto const nNodes = nodes.size();
    std::unordered_map<string, NodeId> nodeIds; // NodeName -> NameID

    Graph graph(nNodes);
    int nodeIndex = 0;
    for (auto const& jNode : nodes)
    {
        graph.setNodeName(nodeIndex, jNode["name"]);
        const auto seq = jNode.find("sequence");
        if (seq != jNode.end())
        {
            graph.setNodeSeq(nodeIndex, *seq);
        }
        assert(nodeIds.count(jNode["name"]) == 0);
        nodeIds[jNode["name"]] = nodeIndex;
        nodeIndex++;
    }
    for (auto const& jEdge : jGraph["edges"])
    {
        const int n1 = nodeIds.at(jEdge["from"]);
        const int n2 = nodeIds.at(jEdge["to"]);
        graph.addEdge(n1, n2);
        const auto labels = jEdge.find("labels");
        if (labels != jEdge.end())
        {
            for (const string& label : *labels)
            {
                graph.addLabelToEdge(n1, n2, label);
            }
        }
    }
    return graph;
}

Json graphToJson(Graph const& graph)
{
    Json json;
    json["nodes"] = Json::array();
    for (size_t i = 0; i != graph.numNodes(); ++i)
    {
        json["nodes"].push_back({ { "name", graph.nodeName(i) }, { "sequence", graph.nodeSeq(i) } });
    }
    json["edges"] = Json::array();
    for (size_t n1 = 0; n1 < graph.numNodes(); ++n1)
    {
        for (NodeId n2 : graph.successors(n1))
        {
            Json edge = { { "from", graph.nodeName(n1) }, { "to", graph.nodeName(n2) } };
            auto const& labels = graph.edgeLabels(n1, n2);
            if (labels.size() > 0)
            {
                edge["labels"] = labels;
            }

            json["edges"].push_back(std::move(edge));
        }
    }
    return json;
}
}
